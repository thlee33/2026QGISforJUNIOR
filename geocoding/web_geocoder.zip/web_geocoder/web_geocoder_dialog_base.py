# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'web_geocoder_dialog_base.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_web_geocoderDialogBase(object):
    def setupUi(self, web_geocoderDialogBase):
        web_geocoderDialogBase.setObjectName("web_geocoderDialogBase")
        web_geocoderDialogBase.resize(600, 142)
        self.gridLayout = QtWidgets.QGridLayout(web_geocoderDialogBase)
        self.gridLayout.setObjectName("gridLayout")
        self.label_4 = QtWidgets.QLabel(web_geocoderDialogBase)
        self.label_4.setObjectName("label_4")
        self.gridLayout.addWidget(self.label_4, 3, 0, 1, 1)
        self.svBtn = QtWidgets.QPushButton(web_geocoderDialogBase)
        self.svBtn.setObjectName("svBtn")
        self.gridLayout.addWidget(self.svBtn, 3, 3, 1, 1)
        self.label = QtWidgets.QLabel(web_geocoderDialogBase)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.runGeo = QtWidgets.QPushButton(web_geocoderDialogBase)
        self.runGeo.setObjectName("runGeo")
        self.gridLayout.addWidget(self.runGeo, 6, 0, 1, 4)
        self.restApi = QtWidgets.QLineEdit(web_geocoderDialogBase)
        self.restApi.setObjectName("restApi")
        self.gridLayout.addWidget(self.restApi, 1, 1, 1, 3)
        self.svText = QtWidgets.QLineEdit(web_geocoderDialogBase)
        self.svText.setEnabled(False)
        self.svText.setObjectName("svText")
        self.gridLayout.addWidget(self.svText, 3, 1, 1, 2)
        self.opText = QtWidgets.QLineEdit(web_geocoderDialogBase)
        self.opText.setEnabled(False)
        self.opText.setObjectName("opText")
        self.gridLayout.addWidget(self.opText, 0, 1, 1, 1)
        self.mQgsProjectionSelectionWidget = QgsProjectionSelectionWidget(web_geocoderDialogBase)
        self.mQgsProjectionSelectionWidget.setObjectName("mQgsProjectionSelectionWidget")
        self.gridLayout.addWidget(self.mQgsProjectionSelectionWidget, 2, 1, 1, 3)
        self.label_2 = QtWidgets.QLabel(web_geocoderDialogBase)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 2, 0, 1, 1)
        self.label_3 = QtWidgets.QLabel(web_geocoderDialogBase)
        self.label_3.setObjectName("label_3")
        self.gridLayout.addWidget(self.label_3, 1, 0, 1, 1)
        self.opBtn = QtWidgets.QPushButton(web_geocoderDialogBase)
        self.opBtn.setObjectName("opBtn")
        self.gridLayout.addWidget(self.opBtn, 0, 3, 1, 1)
        self.progressBar = QtWidgets.QProgressBar(web_geocoderDialogBase)
        self.progressBar.setProperty("value", 0)
        self.progressBar.setObjectName("progressBar")
        self.gridLayout.addWidget(self.progressBar, 4, 0, 1, 4)

        self.retranslateUi(web_geocoderDialogBase)
        QtCore.QMetaObject.connectSlotsByName(web_geocoderDialogBase)

    def retranslateUi(self, web_geocoderDialogBase):
        _translate = QtCore.QCoreApplication.translate
        web_geocoderDialogBase.setWindowTitle(_translate("web_geocoderDialogBase", "web_geocoder"))
        self.label_4.setText(_translate("web_geocoderDialogBase", "지오코딩 텍스트 저장"))
        self.svBtn.setText(_translate("web_geocoderDialogBase", "..."))
        self.label.setText(_translate("web_geocoderDialogBase", "주소 텍스트 데이터"))
        self.runGeo.setText(_translate("web_geocoderDialogBase", "RUN"))
        self.restApi.setText(_translate("web_geocoderDialogBase", "610c9043dc3c9773cf3128600fce137c"))
        self.label_2.setText(_translate("web_geocoderDialogBase", "좌표설정"))
        self.label_3.setText(_translate("web_geocoderDialogBase", "KAKAO REST API KEY"))
        self.opBtn.setText(_translate("web_geocoderDialogBase", "..."))

from qgsprojectionselectionwidget import QgsProjectionSelectionWidget
